
CREATE TABLE Component_option_type (
                Component_option_type_pk BIGINT NOT NULL,
                name VARCHAR(50) NOT NULL,
                description VARCHAR(100) NOT NULL,
                is_active TINYINT NOT NULL,
                PRIMARY KEY (Component_option_type_pk)
);

ALTER TABLE Component_option_type COMMENT 'Identifies whether a component is required or optional';


CREATE TABLE Device_action_type (
                Device_action_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                sort_sequence TINYINT NOT NULL,
                is_active TINYINT NOT NULL,
                PRIMARY KEY (Device_action_type_pk)
);

ALTER TABLE Device_action_type COMMENT 'Device Inquiry, Device software upgrade, Device Log upload';


CREATE UNIQUE INDEX device_action_type_idx
 ON Device_action_type
 ( name );

CREATE TABLE Device_notification_type (
                Device_notification_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                sort_sequence TINYINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Device_notification_type_pk)
);

ALTER TABLE Device_notification_type COMMENT 'Software version, discrepancy, Country code violation, 
Attempt to update software without upgrade privileges, Failure to upgrade device, New device registration';


CREATE UNIQUE INDEX device_notification_type_idx
 ON Device_notification_type
 ( name );

CREATE TABLE Contact_type (
                contact_type_pk BIGINT NOT NULL,
                name VARCHAR(20) NOT NULL,
                sort_sequence TINYINT NOT NULL,
                description VARCHAR(100) NOT NULL,
                PRIMARY KEY (contact_type_pk)
);

ALTER TABLE Contact_type COMMENT 'Primary; Billing; Help Desk';


CREATE UNIQUE INDEX contact_type_idx
 ON Contact_type
 ( name );

CREATE TABLE Device_service_type (
                Device_service_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                sort_sequence TINYINT,
                is_active TINYINT NOT NULL,
                PRIMARY KEY (Device_service_type_pk)
);

ALTER TABLE Device_service_type COMMENT 'e.g., Install, De-install, Inspection, Repair, Log Retrieval, Preventative Maintenance, Upgrade';


CREATE UNIQUE INDEX device_service_type_idx
 ON Device_service_type
 ( name );

CREATE TABLE Language (
                Language_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                is_active TINYINT NOT NULL,
                ISO_639_2Lcode VARCHAR(4) NOT NULL,
                PRIMARY KEY (Language_pk)
);


CREATE UNIQUE INDEX language_idx
 ON Language
 ( name );

CREATE UNIQUE INDEX language_idx1
 ON Language
 ( ISO_639_2Lcode );

CREATE TABLE Country (
                Country_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(200) NOT NULL,
                sort_sequence TINYINT NOT NULL,
                is_active TINYINT NOT NULL,
                ISO_3166_2Lcode VARCHAR(4) NOT NULL,
                PRIMARY KEY (Country_pk)
);


CREATE UNIQUE INDEX country_idx
 ON Country
 ( name );

CREATE UNIQUE INDEX country_idx1
 ON Country
 ( ISO_3166_2Lcode );

CREATE TABLE File_type (
                file_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                is_active TINYINT NOT NULL,
                sort_sequence TINYINT NOT NULL,
                PRIMARY KEY (file_type_pk)
);

ALTER TABLE File_type COMMENT 'Manual (HW, SW)
Release Notes
Software
Service Bulletins
User Guides';


CREATE UNIQUE INDEX file_type_idx
 ON File_type
 ( name );

CREATE TABLE File (
                file_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                file_location VARCHAR(200) NOT NULL,
                file_type_pk BIGINT NOT NULL,
                file_size_MB NUMERIC(10,6) NOT NULL,
                Language_pk BIGINT NOT NULL,
                md5sum VARCHAR(100) NOT NULL,
                upload_date DATETIME NOT NULL,
                PRIMARY KEY (file_pk)
);


CREATE UNIQUE INDEX file_idx
 ON File
 ( name );

CREATE TABLE Component_type (
                Component_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                is_active TINYINT NOT NULL,
                description VARCHAR(100) NOT NULL,
                PRIMARY KEY (Component_type_pk)
);

ALTER TABLE Component_type COMMENT 'Hardware; Software components';


CREATE UNIQUE INDEX component_type_idx
 ON Component_type
 ( name );

CREATE TABLE Component_subtype (
                Component_subtype_pk BIGINT NOT NULL,
                Component_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                is_active TINYINT NOT NULL,
                PRIMARY KEY (Component_subtype_pk)
);

ALTER TABLE Component_subtype COMMENT 'Component subtypes. e.g. Motherboard, OS, Driver etc.';


CREATE UNIQUE INDEX component_subtype_idx
 ON Component_subtype
 ( Component_type_pk, name );

CREATE TABLE Party_type (
                Party_type_pk BIGINT NOT NULL,
                name VARCHAR(40) NOT NULL,
                description VARCHAR(100),
                operating_company_use_flag TINYINT NOT NULL,
                Sort_sequence TINYINT NOT NULL,
                PRIMARY KEY (Party_type_pk)
);

ALTER TABLE Party_type COMMENT 'Customer, Operating company, Business Unit, Facility, Partner; Department; Person';

ALTER TABLE Party_type MODIFY COLUMN operating_company_use_flag BIT COMMENT 'y';


CREATE UNIQUE INDEX party_type_idx
 ON Party_type
 ( name );

CREATE TABLE Party (
                Party_PK BIGINT NOT NULL,
                name VARCHAR(100) NOT NULL,
                Party_type_pk BIGINT NOT NULL,
                Timezone VARCHAR(100) NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Party_PK)
);


CREATE UNIQUE INDEX party_idx
 ON Party
 ( name );

CREATE TABLE Party_email_address (
                party_email_pk BIGINT NOT NULL,
                email_address VARCHAR(100) NOT NULL,
                primary_email_flag TINYINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                PRIMARY KEY (party_email_pk)
);


CREATE INDEX party_email_address_idx
 ON Party_email_address
 ( Party_PK, email_address );

CREATE TABLE Party_voice_address (
                Party_voice_address_pk BIGINT NOT NULL,
                Party_voice_type VARCHAR(20) NOT NULL,
                country_code NUMERIC(4) NOT NULL,
                voice_address VARCHAR(50) NOT NULL,
                voice_extension NUMERIC(6) NOT NULL,
                Party_voice_address_pk_1 TINYINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                PRIMARY KEY (Party_voice_address_pk)
);

ALTER TABLE Party_voice_address COMMENT 'Stores voice contact information for a party';

ALTER TABLE Party_voice_address MODIFY COLUMN Party_voice_type VARCHAR(20) COMMENT 'Mobile, Work, Google, Skype';


CREATE UNIQUE INDEX party_voice_address_idx
 ON Party_voice_address
 ( voice_address, Party_PK );

CREATE TABLE Operating_company (
                Operating_company_pk BIGINT NOT NULL,
                PRIMARY KEY (Operating_company_pk)
);


CREATE TABLE Business_unit (
                Business_unit_Pk BIGINT NOT NULL,
                Operating_company_pk BIGINT NOT NULL,
                BU_Party_pk BIGINT NOT NULL,
                PRIMARY KEY (Business_unit_Pk)
);


CREATE UNIQUE INDEX business_unit_idx
 ON Business_unit
 ( Operating_company_pk, BU_Party_pk );

CREATE TABLE Region (
                region_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                is_active TINYINT NOT NULL,
                Business_unit_Pk BIGINT NOT NULL,
                PRIMARY KEY (region_pk)
);

ALTER TABLE Region COMMENT 'Defines a Covidien Region for a Business Unit';


CREATE UNIQUE INDEX region_idx
 ON Region
 ( name, Business_unit_Pk );

CREATE TABLE BU_Department (
                BU_Department_Pk BIGINT NOT NULL,
                Business_unit_Pk BIGINT NOT NULL,
                Department_Party_PK BIGINT NOT NULL,
                PRIMARY KEY (BU_Department_Pk)
);


CREATE UNIQUE INDEX bu_department_idx
 ON BU_Department
 ( Department_Party_PK, Business_unit_Pk );

CREATE TABLE Person (
                Person_pk BIGINT NOT NULL,
                login_username VARCHAR(100) NOT NULL,
                Person_Party_PK BIGINT NOT NULL,
                Associated_party_pk BIGINT NOT NULL,
                Is_employee TINYINT NOT NULL,
                Department_party_pk BIGINT NOT NULL,
                prefix VARCHAR(20) NOT NULL,
                First_Name VARCHAR(60) NOT NULL,
                middle_name VARCHAR(60) NOT NULL,
                Last_name VARCHAR(60) NOT NULL,
                suffix VARCHAR(20) NOT NULL,
                password_hash VARCHAR(100),
                password_expiration DATETIME,
                Language_pk BIGINT NOT NULL,
                login_failure_count SMALLINT DEFAULT 0 NOT NULL,
                Work_title VARCHAR(100),
                last_login_attempt_datetime DATETIME,
                last_successful_login_datetime DATETIME,
                Locked_until_datetime DATETIME,
                PRIMARY KEY (Person_pk)
);

ALTER TABLE Person MODIFY COLUMN Associated_party_pk BIGINT COMMENT 'Top level organization association';

ALTER TABLE Person MODIFY COLUMN login_failure_count SMALLINT COMMENT 'ogin';


CREATE UNIQUE INDEX person_idx
 ON Person
 ( login_username );

CREATE TABLE Device_notification_subscription (
                Device_notification_subscription_pk BIGINT NOT NULL,
                Person_pk BIGINT NOT NULL,
                Device_notification_type_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Device_notification_subscription_pk)
);


CREATE UNIQUE INDEX device_notification_subscription_idx1
 ON Device_notification_subscription
 ( Person_pk, Device_notification_type_pk, activation_date );

CREATE TABLE login_history (
                login_history_pk BIGINT NOT NULL,
                Person_pk BIGINT NOT NULL,
                Login_timestamp DATETIME NOT NULL,
                hostname VARCHAR(100) NOT NULL,
                successful_login_flag TINYINT NOT NULL,
                PRIMARY KEY (login_history_pk)
);


CREATE UNIQUE INDEX login_history_idx
 ON login_history
 ( Person_pk, Login_timestamp, hostname );

CREATE TABLE Party_contact (
                Party_contact_pk BIGINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                Person_pk BIGINT NOT NULL,
                contact_type_pk BIGINT NOT NULL,
                title VARCHAR(60) NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Party_contact_pk)
);


CREATE UNIQUE INDEX party_contact_idx
 ON Party_contact
 ( Party_PK, Person_pk, contact_type_pk );

CREATE TABLE Device_type (
                Device_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                SW_package_expiration_interval SMALLINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                BU_Party_pk BIGINT NOT NULL,
                PRIMARY KEY (Device_type_pk)
);

ALTER TABLE Device_type COMMENT 'PB980, ForceTriad, Etc.

SW_package_expiration_interval (117)';


CREATE UNIQUE INDEX device_type_idx
 ON Device_type
 ( BU_Party_pk, name );

CREATE TABLE Component (
                Component_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                version VARCHAR(20) NOT NULL,
                Language_pk BIGINT NOT NULL,
                Component_subtype_pk BIGINT NOT NULL,
                Software_package_status VARCHAR(1) NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME,
                sunset_date DATETIME NOT NULL,
                PRIMARY KEY (Component_pk)
);

ALTER TABLE Component COMMENT 'Name and version of the HW or SW component made for a specific BU';

ALTER TABLE Component MODIFY COLUMN Software_package_status VARCHAR(1) COMMENT 'Testing or In Production';


CREATE UNIQUE INDEX component_idx
 ON Component
 ( Device_type_pk, name, version, Language_pk );

CREATE TABLE Component_file (
                Component_file_pk BIGINT NOT NULL,
                Component_pk BIGINT NOT NULL,
                file_pk BIGINT NOT NULL,
                PRIMARY KEY (Component_file_pk)
);

ALTER TABLE Component_file COMMENT 'Identifies files attached to a specific component';


CREATE UNIQUE INDEX component_file_idx
 ON Component_file
 ( Component_pk, file_pk );

CREATE TABLE Notification_VW (
                Person_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                Device_notification_type_pk BIGINT NOT NULL,
                Facility_party_pk BIGINT NOT NULL,
                activation DATETIME NOT NULL,
                expiration DATETIME NOT NULL,
                PRIMARY KEY (Person_pk, Device_type_pk, Device_notification_type_pk, Facility_party_pk)
);


CREATE TABLE Access_Policy (
                Access_policy_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME,
                PRIMARY KEY (Access_policy_pk)
);

ALTER TABLE Access_Policy COMMENT 'Create/Edit users; Download Software Manuals; Download Other Documents (PDF''S); Upload Software Manuals and PDF''s; Upload Software; Assign Software Package Status; Send Email Notifications; etc.';


CREATE UNIQUE INDEX access_policy_idx
 ON Access_Policy
 ( Device_type_pk, name );

CREATE TABLE Device_availability (
                Device_availability_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                Regulatory_Approved TINYINT NOT NULL,
                Country_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Device_availability_pk)
);

ALTER TABLE Device_availability COMMENT 'Countries that the device is available or approved for';


CREATE UNIQUE INDEX device_availability_idx
 ON Device_availability
 ( Device_type_pk, Country_pk );

CREATE TABLE Device_language_availability (
                Device_language_availability_pk BIGINT NOT NULL,
                Device_availability_pk BIGINT NOT NULL,
                Language_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Device_language_availability_pk)
);


CREATE UNIQUE INDEX device_language_availability_idx
 ON Device_language_availability
 ( Device_availability_pk, Language_pk );

CREATE TABLE Device_Type_file (
                Device_file_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                file_pk BIGINT NOT NULL,
                PRIMARY KEY (Device_file_pk)
);

ALTER TABLE Device_Type_file COMMENT 'Identifies files attached to the Device_type';


CREATE UNIQUE INDEX device_type_file_idx
 ON Device_Type_file
 ( Device_type_pk, file_pk );

CREATE TABLE Device_log_field (
                Device_log_field_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                Field_name VARCHAR(60) NOT NULL,
                Log_file_position VARCHAR(200) NOT NULL,
                PRIMARY KEY (Device_log_field_pk)
);


CREATE UNIQUE INDEX device_log_field_idx1
 ON Device_log_field
 ( Device_type_pk, Field_name );

CREATE TABLE Device_type_config (
                Device_type_config_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                config_name VARCHAR(100) NOT NULL,
                version VARCHAR(100) NOT NULL,
                activation_date DATE NOT NULL,
                end_of_life_date DATETIME,
                PRIMARY KEY (Device_type_config_pk)
);


CREATE UNIQUE INDEX device_type_config_idx
 ON Device_type_config
 ( Device_type_pk, config_name, version );

CREATE TABLE Device_type_config_comp (
                Device_type_config_component_pk BIGINT NOT NULL,
                Device_type_config_pk BIGINT NOT NULL,
                Primary_Component_pk BIGINT NOT NULL,
                Related_SW_component_pk BIGINT NOT NULL,
                Component_option_type_pk BIGINT NOT NULL,
                Entitlement_required TINYINT NOT NULL,
                PRIMARY KEY (Device_type_config_component_pk)
);

ALTER TABLE Device_type_config_comp COMMENT 'this relationship only exists for a defined configuration name.';

ALTER TABLE Device_type_config_comp MODIFY COLUMN Entitlement_required BIT COMMENT 'Component requires entitlement rights for each device';


CREATE UNIQUE INDEX device_type_config_component_idx
 ON Device_type_config_comp
 ( Device_type_config_pk, Primary_Component_pk );

CREATE TABLE BU_customer (
                BU_customer_pk BIGINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                Customer_Party_pk BIGINT NOT NULL,
                Activation_date DATETIME NOT NULL,
                Expiration_date DATETIME NOT NULL,
                customer_account_number VARCHAR(20) NOT NULL,
                region_pk BIGINT NOT NULL,
                PRIMARY KEY (BU_customer_pk)
);


CREATE UNIQUE INDEX bu_customer_idx1
 ON BU_customer
 ( Party_PK, Customer_Party_pk );

CREATE TABLE Appl_user_party_auth (
                Appl_user_party_auth_pk BIGINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                Person_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME,
                PRIMARY KEY (Appl_user_party_auth_pk)
);


CREATE UNIQUE INDEX appl_user_party_auth_idx
 ON Appl_user_party_auth
 ( Party_PK, Person_pk );

CREATE TABLE Customer_Facility (
                Customer_facility_pk BIGINT NOT NULL,
                BU_customer_pk BIGINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                Activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Customer_facility_pk)
);


CREATE UNIQUE INDEX customer_facility_idx
 ON Customer_Facility
 ( BU_customer_pk, Party_PK );

CREATE TABLE Device (
                Device_pk BIGINT NOT NULL,
                Device_type_pk BIGINT NOT NULL,
                Device_Serial_number VARCHAR(100) NOT NULL,
                Owner BIGINT NOT NULL,
                Device_type_config_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Device_pk)
);


CREATE UNIQUE INDEX device_idx
 ON Device
 ( Device_type_pk, Device_Serial_number );

CREATE TABLE Device_action_history (
                Device_action_history_pk BIGINT NOT NULL,
                Device_action_type_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                device_action_date DATETIME NOT NULL,
                Person_pk BIGINT NOT NULL,
                PRIMARY KEY (Device_action_history_pk)
);


CREATE UNIQUE INDEX device_action_history_idx
 ON Device_action_history
 ( Device_pk, device_action_date );

CREATE TABLE Device_Comp_Entitlement (
                Device_Component_Entitlement_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                Component_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Device_Component_Entitlement_pk)
);

ALTER TABLE Device_Comp_Entitlement COMMENT 'Maintains a list of components entitled for a device';


CREATE UNIQUE INDEX device_component_entitlement_idx
 ON Device_Comp_Entitlement
 ( Device_pk, Component_pk );

CREATE TABLE Device_Discrepancy (
                Device_Discrepancy_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                Component_pk BIGINT NOT NULL,
                Discrepancy_date DATETIME NOT NULL,
                Resolution_record_date DATE NOT NULL,
                PRIMARY KEY (Device_Discrepancy_pk)
);


CREATE UNIQUE INDEX device_discrepancy_idx
 ON Device_Discrepancy
 ( Device_pk, Component_pk, Discrepancy_date );

CREATE TABLE Device_log_history (
                Device_log_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                Device_log_field_pk BIGINT NOT NULL,
                logged_value VARCHAR(200) NOT NULL,
                log_date DATE NOT NULL,
                PRIMARY KEY (Device_log_pk)
);

ALTER TABLE Device_log_history COMMENT 'History of logged field values from log files';


CREATE UNIQUE INDEX device_log_history_idx
 ON Device_log_history
 ( Device_pk, Device_log_field_pk, log_date );

CREATE TABLE Device_installation (
                device_installation_pk BIGINT NOT NULL,
                Facility_Device_id VARCHAR(100) NOT NULL,
                Facility_Party_PK BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                Activation_date DATETIME NOT NULL,
                Expiration_date DATETIME NOT NULL,
                PRIMARY KEY (device_installation_pk)
);


CREATE UNIQUE INDEX device_installation_idx
 ON Device_installation
 ( Facility_Party_PK, Device_pk, Activation_date );

CREATE TABLE Device_Service_History (
                Device_Service_History_pk BIGINT NOT NULL,
                Device_service_type_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                device_installation_pk BIGINT NOT NULL,
                Service_datetime DATETIME NOT NULL,
                Service_Person_pk BIGINT NOT NULL,
                Service_note VARCHAR(200) NOT NULL,
                PRIMARY KEY (Device_Service_History_pk)
);


CREATE UNIQUE INDEX device_service_history_idx
 ON Device_Service_History
 ( Device_service_type_pk, Device_pk, Service_datetime );

CREATE TABLE Device_component_history (
                Device_component_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                Component_pk BIGINT NOT NULL,
                Component_Serial_number VARCHAR(100) NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                Device_Service_History_pk BIGINT NOT NULL,
                PRIMARY KEY (Device_component_pk)
);

ALTER TABLE Device_component_history COMMENT 'Records all component information and maintains device component history. Also allows to capture serial number of each hardware component used in the device. Useful for recall or maintenance issues,';


CREATE UNIQUE INDEX device_component_history_idx
 ON Device_component_history
 ( Device_pk, Component_pk, Component_Serial_number );

CREATE TABLE Device_setting_history (
                Device_setting_pk BIGINT NOT NULL,
                Device_component_pk BIGINT NOT NULL,
                Device_pk BIGINT NOT NULL,
                Device_setting_name VARCHAR(200) NOT NULL,
                setting_value VARCHAR(100) NOT NULL,
                HW_SW_flag VARCHAR(1) NOT NULL,
                activation_date DATE NOT NULL,
                PRIMARY KEY (Device_setting_pk)
);

ALTER TABLE Device_setting_history COMMENT 'Individual device setting configured for a specific device component';

ALTER TABLE Device_setting_history MODIFY COLUMN HW_SW_flag VARCHAR(1) COMMENT 'Enum ''HW'' or ''SW''';


CREATE UNIQUE INDEX device_setting_idx
 ON Device_setting_history
 ( Device_component_pk, Device_pk, Device_setting_name, activation_date );

CREATE TABLE Address_type (
                Address_type_pk BIGINT NOT NULL,
                name VARCHAR(40) NOT NULL,
                Description VARCHAR(100) NOT NULL,
                sort_sequence TINYINT NOT NULL,
                PRIMARY KEY (Address_type_pk)
);

ALTER TABLE Address_type COMMENT 'Billing; Mailing; Physical location';


CREATE UNIQUE INDEX address_type_idx
 ON Address_type
 ( name );

CREATE TABLE Application_role (
                App_role_pk BIGINT NOT NULL,
                BU_Department_Pk BIGINT NOT NULL,
                name VARCHAR(60) NOT NULL,
                description VARCHAR(100) NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (App_role_pk)
);

ALTER TABLE Application_role COMMENT 'System Admin; Application Support; CSE; Sales Rep; RandD; QA; Service Manager; Biomed';


CREATE UNIQUE INDEX application_role_idx
 ON Application_role
 ( BU_Department_Pk, name );

CREATE TABLE App_Role_Access_Policy (
                App_Role_Access_Policy_pk BIGINT NOT NULL,
                App_role_pk BIGINT NOT NULL,
                permission_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (App_Role_Access_Policy_pk)
);

ALTER TABLE App_Role_Access_Policy COMMENT 'Validate BU is associated with the Device Type';


CREATE UNIQUE INDEX app_role_access_policy_idx1
 ON App_Role_Access_Policy
 ( App_role_pk, permission_pk );

CREATE TABLE person_application_role (
                person_application_role BIGINT NOT NULL,
                Person_pk BIGINT NOT NULL,
                App_role_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME,
                PRIMARY KEY (person_application_role)
);

ALTER TABLE person_application_role COMMENT 'Maintains history of role changes over time';


CREATE UNIQUE INDEX person_application_role_idx
 ON person_application_role
 ( Person_pk, App_role_pk );

CREATE TABLE Postal_address (
                Postal_address_pk BIGINT NOT NULL,
                Line1 VARCHAR(200) NOT NULL,
                Line2 VARCHAR(200) NOT NULL,
                city VARCHAR(100) NOT NULL,
                state_province VARCHAR(100) NOT NULL,
                Postal_code VARCHAR(40) NOT NULL,
                Country_pk BIGINT NOT NULL,
                PRIMARY KEY (Postal_address_pk)
);


CREATE TABLE Party_postal_address (
                Party_postal_address_pk BIGINT NOT NULL,
                Party_PK BIGINT NOT NULL,
                Address_type_pk BIGINT NOT NULL,
                primary_postal_address_flag TINYINT NOT NULL,
                Postal_address_pk BIGINT NOT NULL,
                activation_date DATETIME NOT NULL,
                expiration_date DATETIME NOT NULL,
                PRIMARY KEY (Party_postal_address_pk)
);


CREATE UNIQUE INDEX party_postal_address_idx1
 ON Party_postal_address
 ( Party_PK, Address_type_pk, Postal_address_pk );

ALTER TABLE Device_type_config_comp ADD CONSTRAINT component_option_type_device_type_config_comp_fk
FOREIGN KEY (Component_option_type_pk)
REFERENCES Component_option_type (Component_option_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_action_history ADD CONSTRAINT device_action_type_device_action_history_fk
FOREIGN KEY (Device_action_type_pk)
REFERENCES Device_action_type (Device_action_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_notification_subscription ADD CONSTRAINT device_notification_type_device_notification_subscription_fk
FOREIGN KEY (Device_notification_type_pk)
REFERENCES Device_notification_type (Device_notification_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Notification_VW ADD CONSTRAINT device_notification_type_nptification_vw_fk
FOREIGN KEY (Device_notification_type_pk)
REFERENCES Device_notification_type (Device_notification_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_contact ADD CONSTRAINT contact_type_party_contact_fk
FOREIGN KEY (contact_type_pk)
REFERENCES Contact_type (contact_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Service_History ADD CONSTRAINT device_service_type_device_service_history_fk
FOREIGN KEY (Device_service_type_pk)
REFERENCES Device_service_type (Device_service_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Component ADD CONSTRAINT language_component_fk
FOREIGN KEY (Language_pk)
REFERENCES Language (Language_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE File ADD CONSTRAINT language_file_fk
FOREIGN KEY (Language_pk)
REFERENCES Language (Language_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_language_availability ADD CONSTRAINT language_device_language_availability_fk
FOREIGN KEY (Language_pk)
REFERENCES Language (Language_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Person ADD CONSTRAINT language_person_fk
FOREIGN KEY (Language_pk)
REFERENCES Language (Language_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_availability ADD CONSTRAINT geographic_area_device_availability_fk
FOREIGN KEY (Country_pk)
REFERENCES Country (Country_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Postal_address ADD CONSTRAINT country_postal_address_fk
FOREIGN KEY (Country_pk)
REFERENCES Country (Country_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE File ADD CONSTRAINT file_type_file_fk
FOREIGN KEY (file_type_pk)
REFERENCES File_type (file_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Component_file ADD CONSTRAINT file_component_file_fk
FOREIGN KEY (file_pk)
REFERENCES File (file_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Type_file ADD CONSTRAINT file_device_file_fk
FOREIGN KEY (file_pk)
REFERENCES File (file_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Component_subtype ADD CONSTRAINT component_type_component_subtype_fk
FOREIGN KEY (Component_type_pk)
REFERENCES Component_type (Component_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Component ADD CONSTRAINT component_subtype_component_fk
FOREIGN KEY (Component_subtype_pk)
REFERENCES Component_subtype (Component_subtype_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party ADD CONSTRAINT party_type_party_fk
FOREIGN KEY (Party_type_pk)
REFERENCES Party_type (Party_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_postal_address ADD CONSTRAINT party_business_unit_address_fk
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device ADD CONSTRAINT party_device_fk
FOREIGN KEY (Owner)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_installation ADD CONSTRAINT party_device_installation_fk
FOREIGN KEY (Facility_Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Customer_Facility ADD CONSTRAINT party_customer_facility_fk
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Appl_user_party_auth ADD CONSTRAINT party_appl_user_auth_fk
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE BU_customer ADD CONSTRAINT party_bu_customer_fk
FOREIGN KEY (Customer_Party_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE BU_customer ADD CONSTRAINT party_bu_customer_fk1
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_type ADD CONSTRAINT party_device_type_fk
FOREIGN KEY (BU_Party_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_contact ADD CONSTRAINT party_party_contact_fk
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Person ADD CONSTRAINT associated_party_fk
FOREIGN KEY (Associated_party_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Operating_company ADD CONSTRAINT party_provider_company_fk
FOREIGN KEY (Operating_company_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Business_unit ADD CONSTRAINT party_business_unit_fk
FOREIGN KEY (BU_Party_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE BU_Department ADD CONSTRAINT party_bu_department_fk
FOREIGN KEY (Department_Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Person ADD CONSTRAINT party_person_fk1
FOREIGN KEY (Person_Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_voice_address ADD CONSTRAINT party_party_phone_fk
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_email_address ADD CONSTRAINT party_party_email_fk
FOREIGN KEY (Party_PK)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Notification_VW ADD CONSTRAINT party_nptification_vw_fk
FOREIGN KEY (Facility_party_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Person ADD CONSTRAINT party_person_fk
FOREIGN KEY (Department_party_pk)
REFERENCES Party (Party_PK)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Business_unit ADD CONSTRAINT operator_company_business_unit_fk
FOREIGN KEY (Operating_company_pk)
REFERENCES Operating_company (Operating_company_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE BU_Department ADD CONSTRAINT business_unit_bu_department_fk
FOREIGN KEY (Business_unit_Pk)
REFERENCES Business_unit (Business_unit_Pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Region ADD CONSTRAINT business_unit_region_fk
FOREIGN KEY (Business_unit_Pk)
REFERENCES Business_unit (Business_unit_Pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE BU_customer ADD CONSTRAINT region_bu_customer_fk
FOREIGN KEY (region_pk)
REFERENCES Region (region_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Application_role ADD CONSTRAINT bu_department_application_role_fk
FOREIGN KEY (BU_Department_Pk)
REFERENCES BU_Department (BU_Department_Pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_contact ADD CONSTRAINT person_party_contact_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Appl_user_party_auth ADD CONSTRAINT person_appl_user_auth_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE person_application_role ADD CONSTRAINT person_application_userrole_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE login_history ADD CONSTRAINT person_login_failure_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_notification_subscription ADD CONSTRAINT person_device_notification_subscription_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Service_History ADD CONSTRAINT person_device_service_history_fk
FOREIGN KEY (Service_Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_action_history ADD CONSTRAINT person_device_action_history_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Notification_VW ADD CONSTRAINT person_nptification_vw_fk
FOREIGN KEY (Person_pk)
REFERENCES Person (Person_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device ADD CONSTRAINT device_type_device_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_type_config ADD CONSTRAINT device_type_device_config_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_log_field ADD CONSTRAINT device_type_device_log_field_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Type_file ADD CONSTRAINT device_type_device_file_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_availability ADD CONSTRAINT device_type_device_availability_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Access_Policy ADD CONSTRAINT device_type_permission_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Notification_VW ADD CONSTRAINT device_type_nptification_vw_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Component ADD CONSTRAINT device_type_component_fk
FOREIGN KEY (Device_type_pk)
REFERENCES Device_type (Device_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Component_file ADD CONSTRAINT component_component_file_fk
FOREIGN KEY (Component_pk)
REFERENCES Component (Component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_type_config_comp ADD CONSTRAINT component_device_type_config_component_fk
FOREIGN KEY (Related_SW_component_pk)
REFERENCES Component (Component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_type_config_comp ADD CONSTRAINT component_device_type_config_component_fk1
FOREIGN KEY (Primary_Component_pk)
REFERENCES Component (Component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Discrepancy ADD CONSTRAINT component_device_discrepancy_fk
FOREIGN KEY (Component_pk)
REFERENCES Component (Component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Comp_Entitlement ADD CONSTRAINT component_device_sw_entitlement_fk
FOREIGN KEY (Component_pk)
REFERENCES Component (Component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_component_history ADD CONSTRAINT component_device_component_fk
FOREIGN KEY (Component_pk)
REFERENCES Component (Component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE App_Role_Access_Policy ADD CONSTRAINT permission_permision_assignment_fk
FOREIGN KEY (permission_pk)
REFERENCES Access_Policy (Access_policy_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_language_availability ADD CONSTRAINT device_availability_device_language_availability_fk
FOREIGN KEY (Device_availability_pk)
REFERENCES Device_availability (Device_availability_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_log_history ADD CONSTRAINT device_log_field_device_log_fk
FOREIGN KEY (Device_log_field_pk)
REFERENCES Device_log_field (Device_log_field_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_type_config_comp ADD CONSTRAINT device_typ_config_device_type_config_component_fk
FOREIGN KEY (Device_type_config_pk)
REFERENCES Device_type_config (Device_type_config_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device ADD CONSTRAINT device_typ_config_device_fk
FOREIGN KEY (Device_type_config_pk)
REFERENCES Device_type_config (Device_type_config_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Customer_Facility ADD CONSTRAINT bu_customer_customer_facility_fk
FOREIGN KEY (BU_customer_pk)
REFERENCES BU_customer (BU_customer_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_installation ADD CONSTRAINT device_device_installation_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_setting_history ADD CONSTRAINT device_device_config_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_log_history ADD CONSTRAINT device_device_log_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_component_history ADD CONSTRAINT device_device_component_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Service_History ADD CONSTRAINT device_device_service_history_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Discrepancy ADD CONSTRAINT device_device_discrepancy_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Comp_Entitlement ADD CONSTRAINT device_device_sw_entitlement_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_action_history ADD CONSTRAINT device_device_action_history_fk
FOREIGN KEY (Device_pk)
REFERENCES Device (Device_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_Service_History ADD CONSTRAINT device_installation_device_service_history_fk
FOREIGN KEY (device_installation_pk)
REFERENCES Device_installation (device_installation_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_component_history ADD CONSTRAINT device_service_history_device_component_fk
FOREIGN KEY (Device_Service_History_pk)
REFERENCES Device_Service_History (Device_Service_History_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Device_setting_history ADD CONSTRAINT device_component_history_device_setting_fk
FOREIGN KEY (Device_component_pk)
REFERENCES Device_component_history (Device_component_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_postal_address ADD CONSTRAINT address_type_business_unit_address_fk
FOREIGN KEY (Address_type_pk)
REFERENCES Address_type (Address_type_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE person_application_role ADD CONSTRAINT role_userrole_fk
FOREIGN KEY (App_role_pk)
REFERENCES Application_role (App_role_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE App_Role_Access_Policy ADD CONSTRAINT application_role_permision_assignment_fk
FOREIGN KEY (App_role_pk)
REFERENCES Application_role (App_role_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE Party_postal_address ADD CONSTRAINT address_business_unit_address_fk
FOREIGN KEY (Postal_address_pk)
REFERENCES Postal_address (Postal_address_pk)
ON DELETE NO ACTION
ON UPDATE NO ACTION;
